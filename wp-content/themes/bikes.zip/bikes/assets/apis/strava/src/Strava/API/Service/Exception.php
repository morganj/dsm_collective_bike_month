<?php
namespace Strava\API\Service;

/**
 * Catch me please!
 * 
 * @author Bas van Dorst
 * @package StravaPHP
 */
class Exception extends \Exception {}
