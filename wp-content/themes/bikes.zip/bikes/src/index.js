import LoginButton from './LoginButton';
import React from 'react';
import ReactDOM from 'react-dom';

export default (function () {
    let element = <LoginButton></LoginButton>;
    ReactDOM.render(element, document.body);
}());
