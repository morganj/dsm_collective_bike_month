<?php

/*
Plugin Name: Loom Extra Features
Plugin URI: http://www.madeinebor.com
Description: Adds Custom Widgets & Post Types to your WordPress install, specifically for the Loom WordPress theme by TommusRhodus.
Version: 1.0
Author: TommusRhodus
Author URI: http://www.madeinebor.com
*/	

require_once( plugin_dir_path( __FILE__ ) . 'widgets.php' );
require_once( plugin_dir_path( __FILE__ ) . 'shortcodes.php' );
require_once( plugin_dir_path( __FILE__ ) . 'cpt.php' );